export function getDataFromServerEmulation() {
  const JSONFILE = require('./serverCommentsEmulation');
  return JSONFILE;
}
